import cv2
path = 'E:/OpenCV/DAY 2/dataset/image.jpg'
src = cv2.imread(path)
window_name = 'Image'

image = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY )
#image = cv2.cvtColor(src, cv2.COLOR_BGR2HSV )
# Displaying the image
cv2.imshow(window_name, image)
