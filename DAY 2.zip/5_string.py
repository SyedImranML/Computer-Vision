import cv2
path = "E:/OpenCV/DAY 2/dataset/image.jpg"
image = cv2.imread(path)
window_name = 'Image'
font = cv2.FONT_HERSHEY_SIMPLEX
org = (50, 50)
fontScale = 1 # fontScale
color = (255, 0, 0)

# Line thickness of 2 px
thickness = 2

# Using cv2.putText() method
image = cv2.putText(image, 'hello guys', org, font,
				fontScale, color, thickness, cv2.LINE_AA)


cv2.imshow(window_name, image)
