import cv2
path = 'E:/OpenCV/DAY 2/dataset/image.jpg'
image = cv2.imread(path)
window_name = 'Image'
'''
image = cv2.copyMakeBorder(image, 10, 10, 35, 10, cv2.BORDER_CONSTANT, None, value = 1)
cv2.imshow(window_name, image)

'''
image = cv2.copyMakeBorder(image, 100, 100, 50, 50, cv2.BORDER_REFLECT)
cv2.imshow(window_name, image)

