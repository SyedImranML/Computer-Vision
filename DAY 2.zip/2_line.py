import cv2
path="E:/OpenCV/DAY 2/dataset/image.jpg"
image = cv2.imread(path)
window_name = 'Image'

# Start coordinate,(0, 0)represents the top left corner of image
start_point = (100, 250)

# End coordinate, here (250, 250)represents the bottom right corner of image
end_point = (50, 20)
color = (0, 255, 0)
thickness = 9
image = cv2.line(image, start_point, end_point, color, thickness)
cv2.imshow(window_name, image)
