import cv2
import numpy as np

FILE_NAME = "E:/OpenCV/DAY 2/dataset/image.jpg"
try:
	# Read image from disk.
	img = cv2.imread(FILE_NAME)

	# Get number of pixel horizontally and vertically.
	(height, width) = img.shape[:2]

	# Specify the size of image along with interploation methods.
	# cv2.INTER_AREA is used for shrinking, whereas cv2.INTER_CUBIC
	# is used for zooming.
	#res = cv2.resize(img, (int(width / 2), int(height / 2)), interpolation = cv2.INTER_CUBIC)


	
	# Shape of image in terms of pixels
	(rows, cols) = img.shape[:2]

	# getRotationMatrix2D creates a matrix needed for transformation.
	# We want matrix for rotation w.r.t center to 45 degree without scaling.
	M = cv2.getRotationMatrix2D((cols / 2, rows / 2), 35, 1)
	res = cv2.warpAffine(img, M, (cols, rows))
	

	# Write image back to disk.
	cv2.imwrite('result.jpg', res)
	cv2.imshow('input', img)
	cv2.waitKey(0)
	cv2.imshow('output', res)
	cv2.waitKey(0)

except IOError:
	print ('Error while reading files !!!')



